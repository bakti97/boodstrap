# terakhir
tugas uts
